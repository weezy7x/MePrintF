/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_x.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ebouvy <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/06/27 13:41:53 by ebouvy            #+#    #+#             */
/*   Updated: 2025/06/27 13:41:55 by ebouvy           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "ft_printf.h"

int ft_printf_x(unsigned int n, int booleen)
{
    int count = 0;
    
    if (booleen == 0)
    count += ft_putnbr_base_unsigned(n, "0123456789abcdef");
    else{
        count += ft_putnbr_base_unsigned(n, "0123456789ABCDEF");
    }
    return count;
}
