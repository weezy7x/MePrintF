#include "ft_printf.h"
#include <stdio.h>

int main()
{
    int pos = 42;
    int neg = -123;
    int zero = 0;
    int big_pos = 2147483647;    // INT_MAX
    int big_neg = -2147483648;   // INT_MIN

    printf("=== TESTS DE FT_PRINTF %%d ===\n\n");
    
    // Test 1: Nombre positif simple
    printf("Test 1 - Nombre positif (42):\n");
    printf("printf:    [%d]\n", pos);
    printf("ft_printf: [");
    int ret1 = ft_printf("%d", pos);
    printf("] (retour: %d)\n\n", ret1);
    
    // Test 2: Nombre négatif
    printf("Test 2 - Nombre négatif (-123):\n");
    printf("printf:    [%d]\n", neg);
    printf("ft_printf: [");
    int ret2 = ft_printf("%d", neg);
    printf("] (retour: %d)\n\n", ret2);
    
    // Test 3: Zéro
    printf("Test 3 - Zéro:\n");
    printf("printf:    [%d]\n", zero);
    printf("ft_printf: [");
    int ret3 = ft_printf("%d", zero);
    printf("] (retour: %d)\n\n", ret3);
    
    // Test 4: INT_MAX
    printf("Test 4 - INT_MAX (2147483647):\n");
    printf("printf:    [%d]\n", big_pos);
    printf("ft_printf: [");
    ft_printf("%d", big_pos);
    printf("]\n\n");
    
    // Test 5: INT_MIN (cas difficile)
    printf("Test 5 - INT_MIN (-2147483648):\n");
    printf("printf:    [%d]\n", big_neg);
    printf("ft_printf: [");
    int ret5 = ft_printf("%d", big_neg);
    printf("] (retour: %d)\n\n", ret5);
    
    // Test 6: Test avec du texte autour
    printf("Test 6 - Avec du texte:\n");
    printf("printf:    ");
    printf("La température est %d degrés aujourd'hui.\n", 25);
    printf("ft_printf: ");
    ft_printf("La température est %d degrés aujourd'hui.\n", 25);
    printf("\n");
    
    // Test 7: Plusieurs %d dans la même ligne
    printf("Test 7 - Plusieurs %%d:\n");
    printf("printf:    ");
    printf("J'ai %d pommes et %d oranges, total: %d fruits.\n", 5, 3, 8);
    printf("ft_printf: ");
    ft_printf("J'ai %d pommes et %d oranges, total: %d fruits.\n", 5, 3, 8);
    printf("\n");
    
    // Test 8: Retour de fonction (nombre de caractères)
    printf("Test 8 - Retour de fonction:\n");
    int ret_printf = printf("printf retourne: %d", 123);
    printf(" (retour: %d)\n", ret_printf);
    
    printf("ft_printf retourne: ");
    int ret_ft = ft_printf("%d", 123);
    printf(" (retour: %d)\n", ret_ft);
    
    printf("\n=== FIN DES TESTS ===\n");
    
    return 0;
}